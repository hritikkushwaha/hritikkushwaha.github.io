# Next.js Typing Text Example

This is a minimal Next.js 13 app that animates typing the text:

"I am Hritik Kushwaha"

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000